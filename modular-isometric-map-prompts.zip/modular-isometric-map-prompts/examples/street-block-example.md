# Street Block Example

```text
Convert the uploaded reference image into a modular isometric 2D street-block tile.

Subject:
A long old street block with weathered facade, red awnings, and dense cascading vines with red blossoms.

Must preserve these key features:
aged roofline; exposed brick and plaster; repeated windows; red awnings; hanging green vines; red flowers; row of small ground-floor storefronts; air-conditioning boxes.

Use street-block preset: 2×1 tile, tile width 82% of canvas, tile thickness 6%, building footprint 78% × 42%, automatic depth 0.65W, road connector along front edge. Generate one independent tile only. Aspect ratio 3:4.
```
