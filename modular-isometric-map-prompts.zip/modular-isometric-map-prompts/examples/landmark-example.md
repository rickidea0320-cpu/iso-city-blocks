# Landmark Example

```text
Convert the uploaded reference image into a modular isometric 2D landmark tile.

Subject:
A corner tea shop building with a giant turquoise mascot sculpture on the rooftop.

Must preserve these key features:
curved corner shop facade; green tea signage; large turquoise mascot with long ears, orange nose, closed smiling eyes and waving paw; upper white residential floors; teal balcony railings; orange awnings.

Use landmark / corner-shop preset: 1×1 tile, subject footprint 68% × 56%, automatic depth 0.95W, compact corner-building module. Generate one independent tile only. Aspect ratio 3:4.
```
