# Shop Example

```text
Convert the uploaded reference image into a modular isometric 2D shop tile.

Subject:
A small bright yellow vintage clothing shop with a nostalgic storefront.

Must preserve these key features:
bright yellow facade; large retro marquee sign; text “古着屋” and “Vintage”; glass display window with clothing; central yellow-framed door; two plastic chairs in yellow and pink; red lantern branch on the right; sunflower planter; dark tiled roof.

Required signage text:
“古着屋”, “Vintage”

Use the shop module preset: 1×1 tile, tile width 72% of canvas, tile thickness 7%, building footprint 64% × 48%, building height 60%, automatic depth 0.75W. Preserve colorful cute isometric 2D style. Generate one independent tile only. Aspect ratio 3:4.
```
