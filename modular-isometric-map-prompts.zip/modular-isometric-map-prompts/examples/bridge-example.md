# Bridge Example

```text
Convert the uploaded reference image into a modular isometric 2D bridge tile.

Subject:
A long pedestrian bridge crossing a river.

Must preserve these key features:
long narrow pedestrian deck; wavy white railings; repeated bridge piers; stone entrance plaque; decorative lantern post; green river water; far embankment with trees and simplified buildings.

Required signage text:
“信江步行桥”

Use bridge preset: 3×2 tile, geometric river block, bridge deck width 18%–22% of available tile width, bridge aligned to tile axis, clean edge connectors. Generate one independent tile only. Aspect ratio 3:4.
```
