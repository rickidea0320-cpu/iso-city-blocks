# Modular Isometric Map Prompts

一套用于生成「模块化轴测等距地图资产」的提示词参数系统。

目标不是生成单张好看的场景图，而是生成可以像积木一样拼接的城市地图模块：店铺、桥梁、街区、景点。

适用于 Midjourney、DALL·E、Seedream、即梦、Sora 静帧、Stable Diffusion、ComfyUI、GPT 图像生成等图像模型。不同模型对数字约束的遵循程度不同，但本项目通过统一参数、比例、视角、底座和负面约束，尽量保证输出可复用、可拼接、风格统一。

## 快速开始

1. 上传一张实景参考图。
2. 判断主体类型：`shop` / `bridge` / `street-block` / `landmark`。
3. 打开 `prompts/` 中对应模板。
4. 替换 `{SUBJECT_DESCRIPTION}`、`{KEY_FEATURES}`、`{SIGNAGE_TEXT}` 等字段。
5. 生成图片。

## 核心原则

- 参考图只用于提取主体结构、识别特征、角度参考和比例关系。
- 不模仿参考图摄影风格。
- 每张图只生成一个独立 tile，不生成整张地图。
- 所有 tile 必须使用统一轴测机位。
- 所有主体必须具备合理厚度，不能只是单面立面。
- 资产最终要能拼接成街道、街区或城市地图。

## 目录结构

```text
modular-isometric-map-prompts/
├─ README.md
├─ LICENSE
├─ CONTRIBUTING.md
├─ docs/
│  ├─ parameter-manual.md
│  ├─ style-guide.md
│  └─ workflow.md
├─ prompts/
│  ├─ base-prompt.md
│  ├─ shop.md
│  ├─ bridge.md
│  ├─ street-block.md
│  └─ landmark.md
├─ templates/
│  ├─ prompt-config.yaml
│  └─ module-spec.json
├─ schemas/
│  └─ module-spec.schema.json
└─ examples/
   ├─ shop-example.md
   ├─ bridge-example.md
   ├─ street-block-example.md
   └─ landmark-example.md
```

## 推荐输出规格

- Aspect ratio: `3:4`
- 背景：纯白
- 风格：彩色、可爱、干净线稿、柔和扁平上色、轻微阴影
- 视角：标准轴测等距，无透视消失点
- 模块：完整规则 tile，边缘干净、可拼接

## License

MIT License.
