# Street Block Module Prompt

Use this for: 老街、连续店铺、商业立面、长条街屋、藤蔓街区。

```text
Convert the uploaded reference image into a modular isometric 2D street-block tile.

Subject:
{SUBJECT_DESCRIPTION}

Must preserve these key features:
{KEY_FEATURES}

Required signage text, if any:
{SIGNAGE_TEXT}

Reference image usage:
The uploaded photo is used only for street-block identity, facade rhythm, roofline, repeated storefronts, decorations, material memory, and color logic. Do not copy the photographic perspective or background.

Module type:
Long street-block / continuous storefront module.

Tile parameters:
Use a standard 2×1 isometric tile.
Tile width = 82% of canvas width, tolerance ±2%.
Tile projected height = 38%–44% of tile width.
Tile thickness = 6% of tile width, tolerance ±1%.
Corner radius = 2.5% of tile width.
Safe margin = 6% of tile width.
Pure white background outside the tile.

Camera:
Standard isometric axonometric projection. x/y axes at 30° and 150°. No perspective vanishing point. Vertical lines perfectly vertical. Show the long front facade and the right side face. Front facade visible about 60%; right side about 40%. No front-only elevation, no aerial view.

Building proportion:
Building footprint width = 78% of available tile width, allowed 74%–82%.
Building footprint depth = 42% of available tile depth, allowed 36%–48%.
Building total height = 58% of tile width, allowed 50%–66%.
Place the long block parallel to the front road, set back slightly behind the sidewalk.

Automatic depth completion:
If the reference image is mainly a flat street facade, automatically complete the building depth. For a long street block, side depth D = 0.65 × front facade width W, allowed 0.55W–0.75W. The final block must be a real volume, not a thin wall. Side facade detail density should be 40%–60% of the front.

Street connector:
A straight road must run along the front edge from left edge center to right edge center. Road width must be consistent and connector-ready. Add a continuous sidewalk between road and building. Road, sidewalk, curb, and tile boundaries must be straight and aligned to the isometric grid.

Style:
Colorful cute isometric 2D map asset, clean linework, unified line weight, simplified materials, soft flat colors, light shading, warm muted palette.

Details:
Preserve the most important repeated features: awnings, windows, shopfront rhythm, vines, balconies, lamps, facade texture, signage blocks. Reduce text density. Use 0–3 tiny pedestrians, no large crowds. No vehicles unless essential. All details must stay inside tile boundary.

Negative constraints:
No complex city background, no extra unrelated blocks, no photorealism, no black-and-white line art, no flat facade slice, no irregular base, no road edge overflow, no crowds, no messy signs.

Final modular check:
One 2×1 tile only; clean edges; road connects left-right; block has depth; all objects inside boundary; can connect with other street tiles.

Aspect ratio 3:4.
```
