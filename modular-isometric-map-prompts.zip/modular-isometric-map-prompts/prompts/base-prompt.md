# Base Prompt

```text
Convert the uploaded real-world reference image into a unified modular axonometric isometric 2D map asset.

Reference image usage:
The uploaded reference image is used only to extract the subject identity, structure, key visual features, signage placement, proportions, and architectural logic. Do not copy the photographic style. Do not change the established colorful cute isometric 2D illustration style.

Canvas:
Aspect ratio 3:4. Pure white background outside the tile.

Camera:
Use standard isometric axonometric projection with no perspective vanishing point. The x/y axes are 30° and 150°. All vertical lines remain perfectly vertical. Show about 60% front face and 40% right side face, tolerance ±2%. Roof visibility should be about 12% of the subject depth, allowed range 10%–16%. No bird’s-eye view, no low angle, no dramatic perspective, no toy-box over-thick view.

Tile:
Use one clean standardized modular tile. The tile must have straight, complete, connector-ready edges, uniform thickness, and slight regular corner rounding. Nothing may cross the tile boundary. All objects, shadows, plants, signage, people, props, roads, paths, water, and railings must stay inside the tile safe area.

Style:
Colorful cute isometric 2D illustration, clean linework, consistent line weight, soft flat colors, light cel shading, simplified materials, warm muted palette, polished modular city-map asset. No black-and-white line art, no photorealism, no realistic 3D rendering, no plastic toy material.

Depth completion:
If the uploaded reference is mostly a single facade photo, automatically infer and complete the side depth according to the module type. The final subject must be a complete architectural volume, not a flat facade slice.

Recognition:
Preserve the subject’s most important recognizable features: outline, windows, doors, roof form, signage placement, main colors, and distinctive decorations. Simplify complex small details, but do not change the subject identity.

Modular check before final rendering:
1. Only one independent tile, not a full map.
2. Tile edges are straight, clean, and complete.
3. Camera angle is consistent: about 60% front, 40% side.
4. Subject has enough depth and is not a thin facade.
5. All elements stay inside the tile boundary.
6. The result can be placed beside other modules without visual conflict.
```
