# Shop Module Prompt

Use this for: 古着店、茶店、咖啡店、酒馆、餐厅、买手店、照相馆、小型单体商业。

```text
Convert the uploaded reference image into a modular isometric 2D shop tile.

Subject:
{SUBJECT_DESCRIPTION}

Must preserve these key features:
{KEY_FEATURES}

Required signage text, if any:
{SIGNAGE_TEXT}

Reference image usage:
The uploaded photo is used only for shop identity, facade structure, key decorations, color memory, signage placement, and proportional logic. Do not copy the photographic style.

Module type:
Small shop / single storefront module.

Tile parameters:
Use a standard 1×1 isometric tile.
Tile width = 72% of canvas width, tolerance ±2%.
Tile projected height = 46% of tile width, tolerance ±3%.
Tile thickness = 7% of tile width, tolerance ±1%.
Corner radius = 3% of tile width.
Tile bottom edge is 9% from the canvas bottom, allowed range 8%–10%.
Pure white background outside the tile.

Safe area:
Keep an 8% safety margin inside the tile. All building parts, decorations, signage, props, people, plants, shadows, and road details must stay inside this safe area.

Camera:
Use standard isometric axonometric projection. x/y axes at 30° and 150°. No perspective vanishing point. Vertical lines perfectly vertical. Show 60% front facade and 40% right side facade, tolerance ±2%. Roof visibility about 12% of building depth, allowed 10%–16%. Do not make it a frontal elevation.

Building proportion:
Building footprint width = 64% of available tile width, allowed 60%–66%.
Building footprint depth = 48% of available tile depth, allowed 42%–52%.
Building total height = 60% of tile width, allowed 52%–68%.
Front setback = 12% of tile depth, allowed 10%–14%.
Place the building centered horizontally and slightly toward the rear of the tile.

Automatic depth completion:
If the reference image is mostly front-facing, automatically complete the building depth. For a small shop, side depth D = 0.75 × front facade width W, allowed range 0.65W–0.85W. The final building must be a complete volume, not a thin facade panel. Side facade detail density should be 50% of the front facade, allowed 40%–60%. Side facade may continue materials, windows, pipes, small signs, balcony/AC units, but must not invent a new main entrance or unrelated large decoration.

Tile layout:
Include a compact sidewalk zone in front of the shop. If a road is included, make it a simple modular road strip along the front tile edge, aligned to the tile grid and cleanly cut at the tile boundary. Do not create a full street scene.

Style:
Keep the established colorful cute isometric 2D illustration style: clean linework, consistent line weight, soft flat colors, light cel shading, simplified materials, warm muted palette, polished city-map game asset. Preserve the shop’s signature colors if important.

Details:
Keep details rich but controlled. Allowed: 0–2 tiny figures, 1–3 plants, small props like chairs, lanterns, menu boards, display windows, simplified interior hints. All must stay inside the tile. Avoid clutter.

Negative constraints:
No black-and-white line art, no photorealism, no realistic 3D render, no plastic toy look, no flat facade slice, no irregular tile base, no boundary overflow, no complex street background, no crowds, no cars, no messy advertisements.

Final modular check:
Before rendering, verify: one independent tile; straight complete tile edges; 60/40 front-side angle; sufficient building depth; all objects inside boundary; suitable for map assembly.

Aspect ratio 3:4.
```
