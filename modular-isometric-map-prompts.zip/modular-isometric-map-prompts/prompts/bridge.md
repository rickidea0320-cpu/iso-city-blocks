# Bridge Module Prompt

Use this for: 步行桥、公路桥、廊桥、桥头、河岸桥梁模块。

```text
Convert the uploaded reference image into a modular isometric 2D bridge tile.

Subject:
{SUBJECT_DESCRIPTION}

Must preserve these key features:
{KEY_FEATURES}

Required signage text, if any:
{SIGNAGE_TEXT}

Reference image usage:
The uploaded photo is used only for bridge identity, structure, railing rhythm, tower/arch/cable/pier features, bridgehead details, and riverbank logic. Do not copy photographic lighting or aerial perspective.

Module type:
Bridge / river crossing module.

Tile parameters:
Use a standard 2×2 or 3×2 isometric tile according to bridge length.
Tile width = 78%–84% of canvas width.
Tile thickness = 5%–6% of tile width.
Corner radius = 2.5% of tile width.
Pure white background outside the tile.
All tile edges must be straight, complete, clean, and connector-ready.

Camera:
Use standard isometric axonometric projection. x/y axes at 30° and 150°. No perspective vanishing point. Verticals remain vertical. Bridge should run along a clean tile grid axis, usually from front-center edge to rear-center edge or left-center to right-center depending on the real structure. No drone-like aerial view, no low-angle view, no dramatic perspective.

Bridge proportion:
Bridge deck width = 18%–22% of available tile width.
Bridge span length should connect cleanly to tile edge connectors.
Bridgehead structure stays within the first 10%–14% setback of the tile.
Support piers must be regular, repeated, and fully inside the tile.

River / road interface:
If water is present, river must be a regular geometric water block, not an irregular natural edge. River banks are straight or clean stepped geometric lines. Water ripples may appear inside the tile only and must not cross the tile boundary. Bridge ends must align to tile edge connector points.

Automatic structure completion:
If the photo only shows one bridge side or one approach, infer the full bridge deck thickness, railings on both sides, underside beams, and support piers. Do not make the bridge a flat line. Maintain the visible identity while completing hidden structural depth.

Style:
Colorful cute isometric 2D illustration, clean linework, soft flat colors, light cel shading, simplified materials, warm muted palette. Keep the bridge architecturally clear but not photorealistic.

Details:
Allowed: 0–3 tiny pedestrians, a bridgehead plaque, one lamp, simplified riverbank greenery, a few small background building silhouettes if necessary. Keep them secondary and inside the tile. No cars unless the reference bridge is a road bridge, and even then use 0–2 tiny cars maximum.

Negative constraints:
No black-and-white line art, no drone aerial look, no irregular water edge, no heavy city skyline, no complex traffic, no extra bridges, no photorealism, no plastic 3D, no boundary overflow.

Final modular check:
One bridge tile only; clean tile boundary; bridge connects to edge centers; river/road interfaces are geometric; all objects inside boundary; suitable for map assembly.

Aspect ratio 3:4.
```
