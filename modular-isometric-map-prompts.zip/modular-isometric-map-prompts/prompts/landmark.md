# Landmark Module Prompt

Use this for: 景点、广场、纪念碑、门楼、公园小品、城市地标。

```text
Convert the uploaded reference image into a modular isometric 2D landmark tile.

Subject:
{SUBJECT_DESCRIPTION}

Must preserve these key features:
{KEY_FEATURES}

Required signage text, if any:
{SIGNAGE_TEXT}

Reference image usage:
The uploaded photo is used only for landmark identity, silhouette, structure, key symbols, material memory, and spatial arrangement. Do not copy photographic lighting or background.

Module type:
Landmark / scenic spot module.

Tile parameters:
Choose 1×1 tile for compact landmarks and 2×2 tile for larger scenes.
1×1 tile width = 72% of canvas width, tolerance ±2%.
2×2 tile width = 78%–84% of canvas width.
Tile thickness = 5%–7% of tile width.
Corner radius = 2.5%–3% of tile width.
Pure white background outside the tile.

Camera:
Standard isometric axonometric projection. x/y axes at 30° and 150°. Vertical lines perfectly vertical. Show 60% front and 40% side for architectural landmarks. For sculptural or natural landmarks, keep the dominant face readable while preserving standard tile orientation. No bird’s-eye, no low-angle, no dramatic perspective.

Landmark proportion:
Main subject footprint width = 55%–72% of available tile width.
Main subject footprint depth = 45%–65% of available tile depth.
Main subject height = 45%–75% of tile width.
Environment elements must not exceed 25% of tile area unless the landmark itself is landscape-based.

Automatic depth completion:
If the reference is single-sided, infer a complete volume. Minimum side depth must not be lower than 0.50 × front width W unless the object is intentionally flat, such as a sign wall or relief panel. Side detail density = 40%–60% of front.

Environment:
Include only necessary surrounding elements: plaza floor, small trees, stone steps, railings, water edge, sign stone, benches, or paths. Keep all elements inside tile boundary. Do not create a full scenic panorama.

Style:
Colorful cute isometric 2D illustration, clean linework, soft flat colors, gentle shading, simplified material, warm muted palette, polished map asset.

Details:
0–3 tiny people maximum. Text only if it is important signage. Avoid dense labels and small unreadable copy.

Negative constraints:
No full landscape panorama, no complex background city, no photorealism, no realistic 3D render, no irregular tile, no subject overflow, no black-and-white line art.

Final modular check:
One landmark tile only; clean tile edges; subject has enough volume; all props inside boundary; tile can be placed with other modules.

Aspect ratio 3:4.
```
