# Style Guide

## 风格定位

统一风格为：彩色、可爱、模块化、轴测等距 2D 地图资产。

关键词：

- cute isometric 2D illustration
- modular city-map tile
- clean linework
- soft flat colors
- light cel shading
- simplified materials
- warm muted palette
- connector-ready tile

## 不要变成什么

- 不要黑白线稿
- 不要真实摄影
- 不要高写实 3D 建模
- 不要厚重玩具盒渲染
- 不要复杂场景插画
- 不要完整城市鸟瞰图

## 色彩

- 主色来自参考图识别特征。
- 整体降低饱和度，但保留主体记忆点。
- 阴影轻，不要强对比。
- 背景必须纯白。

## 线条

- 线条干净、统一。
- 轮廓线清楚。
- 小细节可简化。

## 材质

- 石材、木材、玻璃、金属都只做轻微纹理。
- 不做真实材质贴图。
- 不做复杂反光。

## 文字

文字只保留必要招牌。
如果模型容易出错，建议改成：

- 保留主招牌大字
- 其他小字变成抽象图形块
- 不生成密集广告文字
